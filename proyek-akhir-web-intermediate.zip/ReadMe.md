# Install Leaflet dan vite

npm i leaflet
npm install

# instal idb
npm install idb

# Akun Login
email: aadedecomel@gmail.com
password: anakinformatika